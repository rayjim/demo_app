import csv
import json
import os
import copy
import numpy as np
import utils
import datetime
import pickle
import sys
from nltk.tokenize import word_tokenize


class News:
    bert_dict = {}
    affairs = {'announce', 'court', 'litigation', 'lawsuit', 'appint', 'recall'}  # name ... as
    business = {'alliance', 'partnership', 'order', 'deal', 'trade', 'demand', 'supply', 'charge', 'invest',
                'sale'}  # take ... charge -> charge
    corporate = {'share issuance', 'div', 'dividend', 'fund', 'funding', 'ipo', 'jv', 'joint venture', 'acquisition',
                 'merge acquire', 'share repurchase', 'share issuance', 'stock split', 'product', 'prodction',
                 'project'}  # buy ... back
    earnings = {'profit', 'group result', 'earnings', 'parent result', 'financial result', 'group forecast',
                'parent forecast', 'price'}
    ratings = {'target price', 'rating', 'raise', 'moody'}  # raise price, swhitch ... to, scah ... to
    keyword_set = earnings.union(ratings, affairs, corporate, business)

    # keyword_set = affairs.union(ratings, corporate, business)

    def __init__(self, id, headline, topic, related_companies, time):
        self.id = id
        self.headline = headline.lower()
        # self.body = body
        self.time = time
        self.topic = topic
        self.related_companies = related_companies

    @classmethod
    def filter(cls, headline):
        for keyword in cls.keyword_set:
            if keyword in headline:
                return True
        return False

    @classmethod
    def load_bert_file(cls, filename):
        """

        :param filename: the name of the bert file, which is json
        :return:
        """
        cls.bert_dict = json.load(open(filename))

    def get_bert_fixed_vec(self):
        """

        :param bert_file: pre-train feature extracted with BERT model
        :param id: the news id identifying the position in BERT
        :return:
        """
        return self.bert_dict[self.id]


class Company:
    def __init__(self, name):
        """
        News, prices and features are all dicts with date as the keys
        :param name:
        """
        self.name = name
        self.news = {}
        self.features = {}
        self.prices = {}
        self.movement_std = 0
        self.high_price = 0
        self.low_price = float('inf')
        self.high_vol = 0
        self.low_vol = float('inf')

    def set_prices(self, price):
        self.prices = price

    def set_news(self, news):
        self.news = {datetime.datetime.strptime(date, '%Y-%m-%d'): news[date] for date in news}

    def set_movement_std(self, std):
        self.movement_std = std

    def judge_label(self, movement):
        # using this setting because of the weight in loss function
        # print(movement, self.std)
        if movement < -0.5 * self.movement_std:
            return 0
        elif movement > 0.5 * self.movement_std:
            return 1
        else:
            return 2


class GraphSnap:
    def __init__(self, companies, date, node_num):
        self.companies = companies
        self.nodes = [i for i in range(node_num)]
        self.node_headline = [[] for _ in range(node_num)]
        self.node_bert = [np.zeros(768) for _ in range(node_num)]
        self.node_features = [[0 for _ in range(7)] for _ in range(node_num)]
        self.date = date
        self.movement = [2 for _ in range(node_num)]
        self.tpx_movement = 2

    def add_node_text(self, node_id, news_list):
        for news in news_list:
            # id, headline, topic, rics, time,
            # we do not use body here
            n = News(news[0], news[1], news[2], news[3], news[4])
            if News.filter(n.headline):
                self.node_headline[node_id].append(n.headline)
                # print(n.headline)
            self.node_bert[node_id] += n.get_bert_fixed_vec()

    def add_node_movement(self, node_id, movement):
        self.movement[node_id] = self.companies[node_id].judge_label(movement)

    def add_tpx_movement(self, movement):
        self.tpx_movement = movement

    def add_node_feature(self, node_id, feature):
        def scale(p, high, low):
            return (p - low) / float(high - low)

        feature[1] = scale(feature[1], self.companies[node_id].high_price, self.companies[node_id].low_price)  # open
        feature[2] = scale(feature[2], self.companies[node_id].high_price, self.companies[node_id].low_price)  # high
        feature[3] = scale(feature[3], self.companies[node_id].high_price, self.companies[node_id].low_price)  # low
        feature[4] = scale(feature[4], self.companies[node_id].high_price, self.companies[node_id].low_price)  # close
        feature[5] = scale(feature[5], self.companies[node_id].high_vol, self.companies[node_id].low_vol)  # volume
        feature.append(self.companies[node_id].judge_label(feature[0]))  # label of movement
        assert len(feature) == 7, feature
        self.node_features[node_id] = feature

    def get_movement_mask(self):
        movement_mask = []
        for i in range(len(self.movement)):
            # along the number of nodes
            if self.movement[i] != 2:
                movement_mask.append(1)
            else:
                movement_mask.append(0)
        return movement_mask


class GraphSpan:
    def __init__(self, span, hierarchical):
        # each date in the span consists of (date, Snap)
        span = [snap for snap in span if snap is not None]
        self.data = span
        # need to exclude the last hour
        self.size = len(self.data) - 1
        # last_movement, open_price, high, low, close, volume, close-open, high-low
        self.span_features = self.convert_feature([d.node_features for d in self.data[:-1]])
        self.span_nodes = self.data[-1].nodes
        self.span_news_mask = self.get_span_news_mask(self.data[-1].node_headline)
        self.span_text = self.get_span_text(self.data[-1].node_headline, hierarchical=hierarchical)
        self.bert_vec = self.data[-1].node_bert
        self.span_movement = self.data[-1].movement
        self.span_tpx_movement = self.data[-1].tpx_movement
        self.span_movement_mask = self.data[-1].get_movement_mask()
        self.movement_num = sum(self.span_movement_mask)
        # self.valid_node = [d[1].valid_node for d in self.data]

    @staticmethod
    def get_span_news_mask(node_headline_list):
        # node_headline_list: time, node, news_list
        node_mask = []  # mask for each node
        for node in range(len(node_headline_list)):
            # along the node
            node_mask.append(any([len(text) > 1 for text in node_headline_list[node]]))
        return node_mask

    @staticmethod
    def get_span_text(node_headline_list, hierarchical=False):
        if hierarchical:
            result = [[] for _ in range(len(node_headline_list))]
        else:
            result = [['[START]'] for _ in range(len(node_headline_list))]
        for node_id in range(len(node_headline_list)):
            headline_set = set()
            for text in node_headline_list[node_id]:
                if text not in headline_set:
                    headline_set.add(text)
            for text in headline_set:
                if hierarchical:
                    result[node_id].append(word_tokenize(text))
                else:
                    result[node_id].extend(word_tokenize(text))
        if hierarchical:
            for node_id in range(len(result)):
                if len(result[node_id]) == 0:
                    result[node_id].append(['[START]'])
        return result

    def pad_text(self, word_vocab, max_len=None):
        '''
        self.span_text:     (node, seq)
        :param word_vocab:
        :return:
        '''
        mlen = max([len(node_text) for node_text in self.span_text])
        if max_len is not None:
            max_len = min(max_len, mlen)
        else:
            max_len = mlen
        result = []
        span_mask = []
        for node_text in self.span_text:
            words = [word_vocab.word2id(word) for word in node_text][:max_len]
            mask = [1 for _ in words]
            result.append(words + [word_vocab.PAD_token] * (max_len - len(words)))
            span_mask.append(mask + [0] * (max_len - len(mask)))
            assert len(result) == len(span_mask)
        return result, span_mask

    def pad_text_hierarchical(self, word_vocab, max_sent=None, max_len=None):
        text_result = []
        word_mask = []
        sent_mask = []
        m_sent = max([len(n) for n in self.span_text])
        if max_sent is not None:
            m_sent = min(max_sent, m_sent)
        for node_id in range(len(self.span_text)):
            node_text = []
            node_word_mask = []
            m_len = max([len(s) for s in self.span_text[node_id]])
            if max_len is not None:
                m_len = min(max_len, m_len)
            for sent_id in range(len(self.span_text[node_id][:m_sent])):
                words = [word_vocab.word2id(word) for word in self.span_text[node_id][sent_id]][:m_len]
                mask = [1 for _ in words]
                assert len(words) == len(mask)
                words = words + [word_vocab.PAD_token] * (m_len - len(words))
                mask = mask + [0] * (m_len - len(mask))
                assert len(words) == len(mask), (len(words), len(mask), m_len)
                assert len(words) <= m_len, (len(words), m_len)
                node_text.append(words)
                node_word_mask.append(mask)
                assert len(node_text) == len(node_word_mask)
            sent_mask.append(
                [1 for s in self.span_text[node_id][:m_sent]] + [0] * (m_sent - len(self.span_text[node_id])))
            word_mask.append(node_word_mask[:m_sent])
            text_result.append(node_text[:m_sent])
        return text_result, word_mask, sent_mask

    # TODO
    @staticmethod
    def convert_feature(span_features):
        '''
        features: movement, open, high, low, close, volume
        :param span_features:  (span, node, features)
        :return:
        '''
        features = []
        for i in range(len(span_features)):
            node_features = []
            for node_id in range(len(span_features[i])):
                assert len(span_features[i][node_id]) == 7, len(span_features[i][node_id])  # 7 source features
                # 0 is the digit number of last movement,
                node_features.append(  # [span_features[i][node_id][0]] +
                    [span_features[i][node_id][6]] + \
                    [span_features[i][node_id][1]] + [span_features[i][node_id][2]] + \
                    [span_features[i][node_id][3]] + [span_features[i][node_id][4]] + \
                    [span_features[i][node_id][5]])  # + \
                # [span_features[i][node_id][4] - span_features[i][node_id][1]] + \
                # [span_features[i][node_id][2] - span_features[i][node_id][3]])
            features.append(node_features)
        return features


class Graph:
    def __init__(self, companies, tpx, config):
        self.config = config
        self.companies = companies
        self.company_list = []
        self.tpx = tpx
        self.node_num = len(self.companies)
        self.feature_scale = {}
        assert self.node_num == config.node_num, self.node_num
        self.com2id = {}
        self.id2com = []
        self.set_mapping()
        News.load_bert_file(config.bert_file)

    def set_mapping(self):
        for company in self.companies:
            self.com2id[company] = len(self.id2com)
            self.id2com.append(company)
        for id in range(len(self.id2com)):
            self.company_list.append(self.companies[self.id2com[id]])

    def load_adjacency(self):
        adj = [[[0 for _ in range(self.node_num)] for _ in range(self.node_num)] for _ in
               range(self.config.relation_num)]
        adj_dict = json.load(open(self.config.correlation_table))
        for c1 in adj_dict:
            if c1 in self.com2id:
                for c2 in adj_dict[c1]:
                    if c2 in self.com2id:
                        if c1 == c2:
                            for r in range(self.config.relation_num):
                                adj[r][self.com2id[c1]][self.com2id[c2]] = 0
                        score = float(adj_dict[c1][c2])
                        if self.config.relation_num == 1:
                            if abs(score) >= self.config.edge_threshold:
                                adj[0][self.com2id[c1]][self.com2id[c2]] = abs(score)
                        else:
                            if score >= self.config.edge_threshold:
                                adj[0][self.com2id[c1]][self.com2id[c2]] = score
                            elif score <= -self.config.edge_threshold:
                                adj[1][self.com2id[c1]][self.com2id[c2]] = abs(score)
        # print(adj)
        return adj

    def extract_data_span(self):
        dates = {}  # dict of GraphSnaps

        for company in self.companies:
            for date in self.companies[company].prices:
                # find the previous day
                if judge_dataset(date, self.config) >= 0:
                    prev_date = date - datetime.timedelta(days=1)
                    limit_day_num = 0
                    while prev_date not in self.companies[company].prices:
                        prev_date = prev_date - datetime.timedelta(days=1)
                        limit_day_num += 1
                        if limit_day_num == 2:
                            break
                    if limit_day_num == 2:
                        # there is no previous day, maybe this is the first day in the dataset
                        continue
                    if date not in dates:
                        # there are 7 snaps in one day, 0~5 are the price features from the previous day, 6 is the opening
                        dates[date] = [None for _ in range(7)]

                    # hours from the previous day, but the features are used for today, all the hours including the 14:00
                    hour_number = len(self.companies[company].prices[prev_date][0])
                    for hour in range(hour_number):
                        if dates[date][hour] is None:
                            snap = GraphSnap(self.company_list, date, self.config.node_num)
                        else:
                            snap = dates[date][hour]
                        # index 0 is movement, which is calculated as (close-open) of the previous hour
                        prev_movement = 0 if hour == 0 else self.companies[company].prices[prev_date][0][hour - 1]
                        # 1 ~ 6 are the indices of features excluding movement
                        feature = [prev_movement] + [self.companies[company].prices[prev_date][i][hour] for i in
                                                     range(1, 6)]
                        snap.add_node_feature(self.com2id[company], feature)
                        if dates[date][hour] is None:
                            dates[date][hour] = snap
                    # add the movement of the last hour, which is to be predicted without features
                    # -1 is not the last hour, but the close price of the day, which is stored manually
                    prev_day_close = self.companies[company].prices[prev_date][-1]  # the previous day close
                    today_open = self.companies[company].prices[date][1][0]  # the today open
                    # the actual snap that contains the news and the opening movement
                    if dates[date][6] is None:
                        # this is for snap of different companies
                        snap = GraphSnap(self.company_list, date, self.config.node_num)
                        if prev_date in self.tpx.prices and date in self.tpx.prices:
                            prev_day_close = self.tpx.prices[prev_date][4][-1]  # the previous day close
                            today_open = self.tpx.prices[date][1][0]  # the today open
                            snap.add_tpx_movement(
                                self.tpx.judge_label((today_open - prev_day_close) / float(prev_day_close)))
                    else:
                        # we use 6 instead of -1 to prevent exception where there is not enough hour units
                        snap = dates[date][6]
                    snap.add_node_movement(self.com2id[company], (today_open - prev_day_close) / float(prev_day_close))
                    if dates[date][6] is None:
                        dates[date][6] = snap

                    if date in self.companies[company].news:
                        daily_news = self.companies[company].news[date]
                        for i in range(len(daily_news)):
                            hour = int(daily_news[i][-1])
                            # here put in a news_list instead of the news itself according to the add_node_text method
                            if hour >= 5:
                                # the news after 5 is actually the news from yesterday, moved to this day manually
                                # the news belongs to the opening hour
                                if dates[date] is not None:
                                    dates[date][6].add_node_text(self.com2id[company],
                                                                 [self.companies[company].news[date][i]])
                    # to deal with the weekend situation, where to put the news from the weekend to today
                    # if today is not weekend, limit_day_num should be equal to 0
                    for day_delta in range(1, limit_day_num + 1):
                        target_date = date - datetime.timedelta(days=day_delta)
                        if target_date in self.companies[company].news:
                            daily_news = self.companies[company].news[target_date]
                            for i in range(len(daily_news)):
                                if dates[date] is not None:
                                    dates[date][6].add_node_text(self.com2id[company],
                                                                 [self.companies[company].news[target_date][
                                                                      i]])

        data = [(date, dates[date]) for date in dates]
        print('date number', len(data))
        data.sort(key=lambda k: k[0])
        train_spans, dev_spans, test_spans = [], [], []
        for i in range(0, len(data)):
            date = data[i][0]
            dataset = judge_dataset(date, self.config)
            if dataset == 0:
                # contains the daily snaps
                train_spans.append(GraphSpan(data[i][1], hierarchical=self.config.hierarchical))
            elif dataset == 1:
                dev_spans.append(GraphSpan(data[i][1], hierarchical=self.config.hierarchical))
            elif dataset == 2:
                test_spans.append(GraphSpan(data[i][1], hierarchical=self.config.hierarchical))

        return train_spans, dev_spans, test_spans

    @staticmethod
    def padding(batch, max_len):
        result = []
        mask_batch = []
        for s in batch:
            l = copy.deepcopy(s)
            m = [1. for _ in range(len(l))]
            l = l[:max_len]
            m = m[:max_len]
            while len(l) < max_len:
                l.append(0)
                m.append(0.)
            result.append(l)
            mask_batch.append(m)
        return result, mask_batch


def judge_dataset(date, config):
    train_start = datetime.datetime.strptime(config.train_start, "%Y-%m-%d")
    dev_start = datetime.datetime.strptime(config.dev_start, "%Y-%m-%d")
    test_start = datetime.datetime.strptime(config.test_start, "%Y-%m-%d")
    test_end = datetime.datetime.strptime(config.test_end, "%Y-%m-%d")
    if train_start <= date < dev_start:
        return 0
    elif dev_start <= date < test_start:
        return 1
    elif test_start <= date <= test_end:
        return 2
    return -1


def extract_ohlcv_from_hourly(open_price, high, low, close, volume):
    """
    This method is not only designed for extracting information from a specific time period. The parameters should all
    be lists within the specific period.
    :param open_price:
    :param high:
    :param low:
    :param close:
    :param volume:
    :return:
    """
    return open_price[0], max(high), min(low), close[-1], sum(volume)


def map_hourly_price(config):
    csv.field_size_limit(sys.maxsize)
    dir_name = '../topix500'
    company_names = os.listdir(dir_name)
    for fname in company_names:
        if 'hourly' not in fname:
            with open(os.path.join(dir_name, fname)) as csvfile:
                data = {}
                reader = csv.reader(csvfile)
                next(reader)  # first line is header
                for row in reader:
                    # date, time, open_price, high, low, close, volume = row
                    _, close, date, high, low, open_price, time, volume = row
                    date = datetime.datetime.strptime(date, "%Y-%m-%d")
                    time = datetime.datetime.strptime(time, "%H:%M")
                    if judge_dataset(date, config) >= 0:
                        if date not in data:
                            data[date] = {}
                        if time.hour not in data[date]:
                            data[date][time.hour] = []
                        data[date][time.hour].append(
                            [float(open_price), float(high), float(low), float(close), float(volume), time.minute])
                write = open(os.path.join(dir_name, fname.split('.')[0] + '-hourly.csv'), 'w')
                write.write('date,time,o,h,l,c,v\n')
                for date in data:
                    for hour in data[date]:
                        hour_data = sorted(data[date][hour], key=lambda k: k[-1])
                        open_price = [d[0] for d in hour_data]
                        high = [d[1] for d in hour_data]
                        low = [d[2] for d in hour_data]
                        close = [d[3] for d in hour_data]
                        volume = [d[4] for d in hour_data]
                        hour_result = extract_ohlcv_from_hourly(open_price, high, low, close, volume)
                        write.write(date.strftime('%Y-%m-%d') + ',' + str(hour) + ':00' + ',' + ','.join(
                            [str(d) for d in hour_result]) + '\n')
                write.close()


def write_tpx_price(fname='tpx_ohlc.csv'):
    csv.field_size_limit(sys.maxsize)
    write100 = open('tpx100_ohlc.csv', 'w')
    write500 = open('tpx500_ohlc.csv', 'w')
    with open(fname) as csvfile:
        reader = csv.reader(csvfile)
        for _ in range(7):
            next(reader)  # first line is header
        for row in reader:
            date, tpx100_open, tpx100_close, tpx100_high, tpx100_low, tpx500_open, tpx500_close, tpx500_high, tpx500_low = row
            date = datetime.datetime.strptime(date, "%Y/%m/%d")
            write100.write(
                ','.join([date.strftime('%Y-%m-%d'), tpx100_open, tpx100_close, tpx100_high, tpx100_low]) + '\n')
            write500.write(
                ','.join([date.strftime('%Y-%m-%d'), tpx500_open, tpx500_close, tpx500_high, tpx500_low]) + '\n')
    write100.close()
    write500.close()


def read_tpx_price(fname, config):
    csv.field_size_limit(sys.maxsize)
    data = {}
    with open(fname) as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            date, open_price, close_price, high, low = row
            date = datetime.datetime.strptime(date, "%Y-%m-%d")
            if judge_dataset(date, config) < 0:
                continue
            data[date] = (float(open_price), float(close_price), float(high), float(low))
    open_close_prices = [(date, data[date][0], data[date][1]) for date in data]
    open_close_prices.sort(key=lambda k: k[0])
    movements = [(open_close_prices[i][1] - open_close_prices[i - 1][2]) / open_close_prices[i - 1][2] for i in
                 range(1, len(open_close_prices))]
    high_price = max([data[date][2] for date in data])
    low_price = min([data[date][3] for date in data])
    movement_std = np.std(movements)
    return data, movement_std, high_price, low_price


def read_price(fname, config):
    # read the trade history of one company
    csv.field_size_limit(sys.maxsize)
    data = {}
    movements = []
    with open(fname) as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # first line is header
        for row in reader:
            date, time, open_price, high, low, close, volume = row
            # _, close, date, high, low, open_price, time, volume = row
            date = datetime.datetime.strptime(date, "%Y-%m-%d")
            time = datetime.datetime.strptime(time, "%H:%M")
            if judge_dataset(date, config) < 0:
                continue
            if date not in data:
                data[date] = []
            data[date].append([float(open_price), float(high), float(low), float(close), float(volume), int(time.hour)])
    result_data = {}
    for date in data:
        # 6 here to exclude 15:00 useless data
        daily_data = data[date]
        open_price = [d[0] for d in daily_data][:6]
        high_price = [d[1] for d in daily_data][:6]
        low_price = [d[2] for d in daily_data][:6]
        close_price = [d[3] for d in daily_data][:6]
        volume = [d[4] for d in daily_data][:6]
        movement = [(c - o) / float(o) for c, o in zip(open_price, close_price)]
        movements.extend(movement)
        day_close = data[date][-1][3]
        # 6 here to exclude 15:00 data from features
        result_data[date] = [movement[:6], open_price[:6], high_price[:6], low_price[:6], close_price[:6], volume[:6],
                             day_close]
    if len(result_data) == 0:
        return None
    highest_price = max([max(result_data[d][2]) for d in result_data])
    lowest_price = min([min(result_data[d][3]) for d in result_data])
    highest_vol = max([max(result_data[d][5]) for d in result_data])
    lowest_vol = min([min(result_data[d][5]) for d in result_data])
    '''
    open_prices = [(d, result_data[d][1][0]) for d in result_data]
    open_prices.sort(key=lambda k: k[0])
    close_prices = [(d, result_data[d][4][-1]) for d in result_data]
    close_prices.sort(key=lambda k: k[0])
    for i in range(len(close_prices) - 1):
        movements.append((open_prices[i + 1][1] - close_prices[i][1]) / close_prices[i][1])
    '''
    movement_std = np.std(movements)
    return result_data, movement_std, highest_price, lowest_price, highest_vol, lowest_vol


def extract_news_headline_vocab(companies):
    word_count = {}
    for company in companies:
        for news_date in companies[company]:
            news_list = companies[company][news_date]
            for news in news_list:
                headline = news[1]
                words = word_tokenize(headline.strip())
                for word in words:
                    if word not in word_count:
                        word_count[word] = 0
                    word_count[word] += 1
    word_count = [(word, word_count[word]) for word in word_count]
    word_count.sort(key=lambda k: k[1], reverse=True)
    write = open('headline_vocab.txt', 'w')
    for pair in word_count:
        write.write(pair[0] + ' ' + str(pair[1]) + '\n')
    write.close()


def read_company_list(list_file='group-code.csv'):
    core30 = set()
    large70 = set()
    lines = open(list_file).readlines()
    for i in range(1, len(lines)):
        code, group = lines[i].strip().split(',')
        if group == 'CORE30':
            core30.add(code)
        elif group == 'LARGE70':
            large70.add(code)
    return core30, large70


def read_data(config):
    print('reading date')
    companies = {}
    company_names = os.listdir(config.price_dir)
    news = json.load(open(config.news_json))
    prices = {}
    for company_file in company_names:
        company_name = (company_file.split('.')[0]).split('-')[0]
        # print(company_name, company_name in company_set)
        if company_name not in news:
            continue
        prices[company_name] = read_price(os.path.join(config.price_dir, company_file), config)
        if prices[company_name] is None or company_name not in news:
            continue
        if company_name not in companies:
            companies[company_name] = Company(company_name)
        companies[company_name].set_prices(prices[company_name][0])
        companies[company_name].set_movement_std(prices[company_name][1])
        companies[company_name].high_price = max(companies[company_name].high_price, prices[company_name][2])
        companies[company_name].low_price = min(companies[company_name].low_price, prices[company_name][3])
        companies[company_name].high_vol = max(companies[company_name].high_vol, prices[company_name][4])
        companies[company_name].low_vol = min(companies[company_name].low_vol, prices[company_name][5])
    '''
    tpx_price, tpx_std, tpx_high, tpx_low = read_tpx_price(config.tpx_price, config)
    tpx = Company('TPX')
    tpx.set_prices(tpx_price)
    tpx.set_movement_std(tpx_std)
    tpx.high_price = tpx_high
    tpx.low_price = tpx_low
    '''
    tpx_price = read_price(config.tpx_price, config)
    tpx = Company('TPX')
    tpx.set_prices(tpx_price[0])
    tpx.set_movement_std(tpx_price[1])
    tpx.high_price = tpx_price[2]
    tpx.low_price = tpx_price[3]
    for company in news:
        # print('news')
        # print(company, company in company_set)
        company_name = company
        if company_name not in companies:
            continue
            # companies[company_name] = Company(company_name)
        companies[company_name].set_news(news[company])
    return companies, tpx, prices, news


def write_stocknet_format(companies):
    for company in companies:
        write = open(os.path.join('price', company + '.txt'), 'w')
        price_data = [(date, companies[company].prices[date]) for date in companies[company].prices]
        price_data.sort(key=lambda k: k[0])
        for i in range(len(price_data)):
            date, data = price_data[i]
            m, o, h, l, c, v, day_close = data
            o = o[0]
            h = max(h)
            l = min(l)
            c = c[-1]
            v = sum(v)
            if i > 0:
                prev_close = price_data[i - 1][1][-1]
            else:
                prev_close = o
            movement = (o - prev_close) / float(prev_close)
            write.write('\t'.join([str(s) for s in [date.strftime('%Y-%m-%d'), movement, o, h, l, c, v]]) + '\n')
        write.close()
        for date in companies[company].news:
            year = date.year
            month = date.month
            day = date.day
            if not os.path.exists(os.path.join(os.getcwd(), 'news', company)):
                os.mkdir(os.path.join(os.getcwd(), 'news', company))
            daily_news = companies[company].news[date]
            for news in daily_news:
                hour = int(news[-1])
                if hour >= 5:
                    this_date = date - datetime.timedelta(days=1)
                    this_year = this_date.year
                    this_month = this_date.month
                    this_day = this_date.day
                    # date_time = date+datetime.timedelta(hours=news[-1])
                    write = open(os.path.join(os.getcwd(), 'news', company, this_date.strftime('%Y-%m-%d') + '.txt'),
                                 'a')
                else:
                    write = open(os.path.join(os.getcwd(), 'news', company, date.strftime('%Y-%m-%d') + '.txt'), 'a')
                news_json = json.dumps({'text': news[1], 'created_at': None, 'user_id_str': None})
                write.write(news_json + 'n')
                write.close()


if __name__ == '__main__':
    # companies = json.load(open('company_news.json'))
    # extract_news_headline_vocab(companies)
    # config = utils.read_config('../config.yaml')
    # map_hourly_price(config)
    # companies, _, _, _, _, _, _ = read_data(config)
    # write_stocknet_format(companies)
    write_tpx_price()
