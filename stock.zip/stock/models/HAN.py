import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence as pack
from torch.nn.utils.rnn import pad_packed_sequence as unpack
import models
from torch.nn.utils.rnn import pad_sequence
from Data import *

import numpy as np


class attentive_pooling(nn.Module):
    def __init__(self, hidden_size):
        super(attentive_pooling, self).__init__()
        self.w = nn.Linear(hidden_size, hidden_size)
        self.u = nn.Linear(hidden_size, 1, bias=False)

    def forward(self, memory, mask=None):
        h = torch.tanh(self.w(memory))
        score = torch.squeeze(self.u(h), -1)
        if mask is not None:
            score = score.masked_fill(mask.eq(0), -1e9)
        alpha = F.softmax(score, -1)
        s = torch.sum(torch.unsqueeze(alpha, -1) * memory, 1)
        return s


class Encoder(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, dropout, bidirec):
        super(Encoder, self).__init__()
        self.rnn = nn.LSTM(input_size=input_size, hidden_size=hidden_size,
                           num_layers=num_layers, dropout=dropout, bidirectional=bidirec,
                           batch_first=True)

    def forward(self, input, lengths):
        total_length = input.size(1)
        length, indices = torch.sort(lengths, dim=0, descending=True)
        _, ind = torch.sort(indices, dim=0)
        input_length = list(torch.unbind(length, dim=0))
        embs = pack(torch.index_select(input, dim=0, index=indices), input_length, batch_first=True)
        outputs, _ = self.rnn(embs)
        outputs = unpack(outputs, batch_first=True, total_length=total_length)[0]
        outputs = torch.index_select(outputs, dim=0, index=ind)
        return outputs


class hierarchical_attention(nn.Module):
    def __init__(self, config, vocab):
        super(hierarchical_attention, self).__init__()
        self.vocab = vocab
        self.vocab_size = vocab.voc_size
        if vocab.emb is not None:
            self.embedding = nn.Embedding.from_pretrained(torch.from_numpy(vocab.emb), freeze=config.freeze_emb)
        else:
            self.embedding = nn.Embedding(vocab.voc_size, config.emb_size)
        self.word_encoder = Encoder(config.emb_size, config.hidden_size, 1, config.dropout, True)
        self.word_attentive_pool = attentive_pooling(config.hidden_size*2)
        self.sentence_encoder = Encoder(config.hidden_size*2, config.hidden_size, 1,
                                        config.dropout, True)
        self.sentence_attentive_pool = attentive_pooling(config.hidden_size)
        self.w_context = nn.Linear(config.hidden_size*2, config.hidden_size, bias=False)
        self.w_out = nn.Linear(config.hidden_size, config.label_size)
        self.tanh = nn.Tanh()
        self.config = config
        self.log_softmax = nn.LogSoftmax()

    def encode(self, contents, contents_mask, sent_mask):
        sent_vec_batch = []
        for content, content_mask in zip(contents, contents_mask):
            length = torch.sum(content_mask, -1)
            emb = self.embedding(content)
            #print('emb size', emb.size())
            context = self.word_encoder(emb, length)
            #print(context.size(), content_mask.size())
            #sent_vec = self.word_attentive_pool(context, content_mask)
            sent_vec = self.word_attentive_pool(context)
            sent_vec_batch.append(sent_vec)
        sent_vec_batch = pad_sequence(sent_vec_batch, batch_first=True)
        sent_hidden = self.sentence_encoder(sent_vec_batch, torch.sum(sent_mask, -1))
        sent_hidden = self.tanh(self.w_context(sent_hidden))
        state = self.sentence_attentive_pool(sent_hidden, sent_mask)
        return sent_hidden, state

    def forward(self, span_nodes, bert_vec, node_text, word_mask, sent_mask, node_feature, adj):
        context, state = self.encode(node_text, word_mask, sent_mask)
        output = self.w_out(state)
        return output, self.w_out(torch.mean(state, 0))
