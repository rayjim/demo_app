import time
import argparse
import torch
import torch.nn as nn
from optims import Optim
import utils
import lr_scheduler as L
from models import *
import torch.nn.functional as F
from tqdm import tqdm
import sys
import os
import random
from Data import *
import numpy as np
import math
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn import svm


def main(vocab, dataloader):
    # clf = RandomForestClassifier()
    # clf = svm.SVC()
    clf = LogisticRegression()
    # clf = GaussianNB()
    data = []
    label = []
    for span in dataloader.train:
        span_nodes, bert_vec, node_text, text_mask, sentence_mask, node_features, last_movement, tpx_movement, movement_mask, news_mask, movement_num = span
        assert len(node_text) == len(movement_mask)
        assert len(movement_mask) == len(news_mask)
        assert len(news_mask) == len(last_movement)
        for bert, m_mask, n_mask, y in zip(bert_vec.numpy(), movement_mask.numpy(), news_mask.numpy(),
                                           last_movement.numpy()):
            if m_mask and n_mask:
                #emb = vocab.sent2emb(text)
                emb = bert
                data.append(emb)
                label.append(y)
    clf.fit(data, label)
    data = []
    label = []
    for span in dataloader.test:
        span_nodes, bert_vec, node_text, text_mask, sentence_mask, node_features, last_movement, tpx_movement, movement_mask, news_mask, movement_num = span
        assert len(node_text) == len(movement_mask)
        assert len(movement_mask) == len(news_mask)
        assert len(news_mask) == len(last_movement)
        for bert, m_mask, n_mask, y in zip(bert_vec.numpy(), movement_mask.numpy(), news_mask.numpy(),
                                           last_movement.numpy()):
            if m_mask and n_mask:
                #emb = vocab.sent2emb(text)
                emb = bert
                data.append(emb)
                label.append(y)
    result = clf.predict(data)
    # result = [int(random.random() > 0.5) for _ in range(len(label))]
    result = np.array(result)
    label = np.array(label)
    right = np.sum(result == label)
    tp = np.sum((result == label) * label)
    tn = right - tp
    fp = np.sum((result != label) * label)
    fn = len(label) - right - fp
    acc = right / float(len(label))
    mcc = (tp * tn - fp * fn) / math.sqrt(float((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)))
    print('evaluate acc %.2f, mcc %.4f' % (acc * 100, mcc))
    print('label number', len(label), np.sum(label))


if __name__ == '__main__':
    config = utils.read_config('config.yaml')
    vocab = Vocab(config.vocab_file, config.emb_file, emb_size=config.emb_size,
                  vocab_size=config.vocab_size, use_pre_emb=config.use_pre_emb)
    # Load data
    start_time = time.time()
    print('loading data...\n')
    dataloader = DataLoader(config, vocab)
    print("DATA loaded!")
    # data
    print('loading time cost: %.3f' % (time.time() - start_time))
    main(vocab, dataloader)
